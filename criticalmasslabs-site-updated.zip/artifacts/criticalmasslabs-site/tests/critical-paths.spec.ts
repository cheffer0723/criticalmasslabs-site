import { expect, test } from '@playwright/test';

const atlasProjects = [
  'ASYMMETRY',
  'Obsidian Abyss',
  'Devolution',
  'Deep Stellar',
  'Agent Ledger',
  'ONYX',
  'MINOS',
  'The Hexagon',
  'Protocol X-402',
];

test.describe('Critical Mass Labs interaction paths', () => {
  test('skip link moves focus to the main content', async ({ page }) => {
    await page.goto('/');

    await page.getByRole('link', { name: 'Skip to content' }).focus();
    await page.keyboard.press('Enter');

    await expect(page).toHaveURL(/#main$/);
    await expect(page.locator('main#main')).toBeFocused();
  });

  test('mobile navigation opens, exposes links, and closes by Escape or selection', async ({
    page,
  }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto('/');

    const mobileNavigation = page.getByRole('navigation', {
      name: 'Mobile navigation',
    });
    const menuToggle = () => page.getByRole('button', { name: /navigation/ });

    await expect(menuToggle()).toHaveAttribute('aria-expanded', 'false');
    await menuToggle().click();
    await expect(menuToggle()).toHaveAttribute('aria-expanded', 'true');
    await expect(mobileNavigation).toBeVisible();
    await expect(mobileNavigation.getByRole('link')).toHaveCount(4);

    await page.keyboard.press('Escape');
    await expect(menuToggle()).toHaveAttribute('aria-expanded', 'false');
    await expect(mobileNavigation).toBeHidden();

    await menuToggle().click();
    await mobileNavigation.getByRole('link', { name: 'About' }).click();
    await expect(page).toHaveURL(/#about$/);
    await expect(menuToggle()).toHaveAttribute('aria-expanded', 'false');
    await expect(mobileNavigation).toBeHidden();
  });

  test('every atlas entry opens the matching status dialog and restores focus', async ({
    page,
  }) => {
    await page.goto('/');

    const atlasRows = page.locator('.atlas-list .atlas-row');
    const dialog = page.getByRole('dialog');

    await expect(atlasRows).toHaveCount(atlasProjects.length);

    for (const [index, projectName] of atlasProjects.entries()) {
      const trigger = atlasRows.nth(index);
      await trigger.scrollIntoViewIfNeeded();

      for (const closeMethod of ['Escape', 'backdrop', 'close button']) {
        await trigger.click();
        await expect(dialog).toBeVisible();
        await expect(dialog.getByRole('heading', { name: projectName })).toBeVisible();

        if (closeMethod === 'Escape') {
          await page.keyboard.press('Escape');
        } else if (closeMethod === 'backdrop') {
          await page.locator('.dialog-backdrop').click({ position: { x: 8, y: 8 } });
        } else {
          await dialog.getByRole('button', { name: 'Close project status' }).click();
        }

        await expect(dialog).toBeHidden();
        await expect(trigger).toBeFocused();
      }
    }
  });

  test('cycles keyboard focus inside linked and indexed status dialogs', async ({
    page,
  }) => {
    await page.goto('/');

    const atlasRows = page.locator('.atlas-list .atlas-row');
    const dialog = page.getByRole('dialog');
    const dialogControls = dialog.locator('button, a[href]');
    const dialogCases = [
      { index: 0, name: 'ASYMMETRY', controlCount: 3 },
      { index: 2, name: 'Devolution', controlCount: 2 },
    ];

    for (const { index, name, controlCount } of dialogCases) {
      await atlasRows.nth(index).scrollIntoViewIfNeeded();
      await atlasRows.nth(index).click();

      await expect(dialog).toBeVisible();
      await expect(dialog.getByRole('heading', { name })).toBeVisible();
      await expect(dialogControls).toHaveCount(controlCount);

      const firstControl = dialogControls.first();
      const lastControl = dialogControls.last();

      await expect(firstControl).toBeFocused();
      await page.keyboard.press('Shift+Tab');
      await expect(lastControl).toBeFocused();
      await page.keyboard.press('Tab');
      await expect(firstControl).toBeFocused();

      await dialog.getByRole('button', { name: 'Close project status' }).click();
      await expect(dialog).toBeHidden();
    }
  });

  test('reduced-motion mode still renders the full public register', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto('/');

    await expect(page.locator('main#main')).toBeVisible();
    await expect(page.locator('.atlas-list .atlas-row')).toHaveCount(9);
    await expect(page.locator('.portfolio-grid .portfolio-card')).toHaveCount(9);
    await expect(page.getByRole('heading', { name: 'The register is open' })).toBeVisible();
    await expect(page.getByText('Additional notes and research artifacts')).toBeVisible();
  });
});