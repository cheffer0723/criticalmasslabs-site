import { useEffect, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowUpRight,
  ExternalLink,
  Menu,
  X,
} from 'lucide-react';

type Project = {
  number: string;
  slug: string;
  name: string;
  mark: string;
  accent: 'violet' | 'cyan' | 'white';
  description: string;
  status: string;
  stage: string;
  discipline: string;
  link?: string;
  linkLabel?: string;
};

const projects: Project[] = [
  {
    number: '01',
    slug: 'asymmetry',
    name: 'ASYMMETRY',
    mark: '◉',
    accent: 'violet',
    description:
      'Privacy-conscious coordination and private settlement research, shaped into simple user-facing tools.',
    status: 'Active research',
    stage: 'Pre-beta',
    discipline: 'Privacy systems',
    link: 'https://asymmetria.io/',
    linkLabel: 'Visit asymmetria.io',
  },
  {
    number: '02',
    slug: 'obsidian-abyss',
    name: 'Obsidian Abyss',
    mark: '⌁',
    accent: 'violet',
    description:
      'A dark research environment for simulation, tooling, and cinematic web experiments.',
    status: 'Skunkworks initiative',
    stage: 'In exploration',
    discipline: 'Simulation + tooling',
    link: 'https://obsidian-abyss.xyz/',
    linkLabel: 'Visit Obsidian Abyss',
  },
  {
    number: '03',
    slug: 'devolution',
    name: 'Devolution',
    mark: '›_',
    accent: 'violet',
    description:
      'Legacy system recovery reduced to testable decisions, evidence, and rebuild discipline.',
    status: 'Research program',
    stage: 'Indexed',
    discipline: 'System recovery',
  },
  {
    number: '04',
    slug: 'deep-stellar',
    name: 'Deep Stellar',
    mark: '✦',
    accent: 'cyan',
    description:
      'A response framework for memory, candor, and useful next steps.',
    status: 'Research program',
    stage: 'Indexed',
    discipline: 'Response systems',
  },
  {
    number: '05',
    slug: 'agent-ledger',
    name: 'Agent Ledger',
    mark: '▣',
    accent: 'violet',
    description:
      'Durable traces for agent actions, attribution, and accountability.',
    status: 'Research program',
    stage: 'Indexed',
    discipline: 'Agent accountability',
  },
  {
    number: '06',
    slug: 'onyx',
    name: 'ONYX',
    mark: '◇',
    accent: 'cyan',
    description:
      'Resilient-systems research carried forward from older engine work.',
    status: 'Research program',
    stage: 'Indexed',
    discipline: 'Resilient systems',
  },
  {
    number: '07',
    slug: 'minos',
    name: 'MINOS',
    mark: '∷',
    accent: 'violet',
    description:
      'Decision-path research for constrained systems, gates, and exits.',
    status: 'Research program',
    stage: 'Indexed',
    discipline: 'Decision paths',
  },
  {
    number: '08',
    slug: 'the-hexagon',
    name: 'The Hexagon',
    mark: '⬡',
    accent: 'cyan',
    description:
      'A six-perspective review council for decisions, blind spots, and trade discipline.',
    status: 'Research program',
    stage: 'Indexed',
    discipline: 'Review systems',
  },
  {
    number: '09',
    slug: 'protocol-x-402',
    name: 'Protocol X-402',
    mark: '›_',
    accent: 'violet',
    description:
      'Interoperability research for payments, access, and system handoffs.',
    status: 'Research program',
    stage: 'Indexed',
    discipline: 'Interoperability',
  },
];

const navItems = [
  { label: 'About', href: '#about' },
  { label: 'Method', href: '#method' },
  { label: 'Atlas', href: '#portfolio' },
  { label: 'Materials', href: '#materials' },
];

function BrandMark() {
  return (
    <img
      className="brand-mark"
      src={`${import.meta.env.BASE_URL}critical-mass-labs-mark.png`}
      alt=""
      aria-hidden="true"
    />
  );
}

function ExternalArrow() {
  return <ArrowUpRight size={14} strokeWidth={1.4} aria-hidden="true" />;
}

function SectionLabel({
  eyebrow,
  children,
}: {
  eyebrow: string;
  children: React.ReactNode;
}) {
  return (
    <div className="section-heading">
      <p className="eyebrow">
        <span className="eyebrow-line" aria-hidden="true" />
        {eyebrow}
      </p>
      <h2>{children}</h2>
    </div>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const menuToggleRef = useRef<HTMLButtonElement>(null);
  const mobileNavRef = useRef<HTMLElement>(null);
  const dialogRef = useRef<HTMLDivElement>(null);
  const openerRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (!selectedProject) return;

    const previousFocus = document.activeElement as HTMLElement | null;
    const dialog = dialogRef.current;
    const focusableSelector =
      'button, a[href], [tabindex]:not([tabindex="-1"])';

    const focusDialog = () => {
      const firstFocusable = dialog?.querySelector<HTMLElement>(
        focusableSelector,
      );
      firstFocusable?.focus();
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        setSelectedProject(null);
        return;
      }

      if (event.key !== 'Tab' || !dialog) return;
      const focusable = Array.from(
        dialog.querySelectorAll<HTMLElement>(focusableSelector),
      );
      if (focusable.length === 0) return;

      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.body.classList.add('dialog-open');
    document.addEventListener('keydown', handleKeyDown);
    const focusTimer = window.setTimeout(focusDialog, 0);

    return () => {
      window.clearTimeout(focusTimer);
      document.body.classList.remove('dialog-open');
      document.removeEventListener('keydown', handleKeyDown);
      (openerRef.current ?? previousFocus)?.focus();
    };
  }, [selectedProject]);

  useEffect(() => {
    if (!menuOpen) return;

    mobileNavRef.current?.querySelector<HTMLAnchorElement>('a')?.focus();

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        setMenuOpen(false);
        menuToggleRef.current?.focus();
      }
    };
    document.addEventListener('keydown', closeOnEscape);
    return () => document.removeEventListener('keydown', closeOnEscape);
  }, [menuOpen]);

  const closeMenu = () => {
    setMenuOpen(false);
    menuToggleRef.current?.focus();
  };

  const openProject = (project: Project, trigger: HTMLButtonElement) => {
    openerRef.current = trigger;
    setSelectedProject(project);
  };

  const closeProject = () => setSelectedProject(null);

  return (
    <>
    <div
      className="site-shell"
      id="top"
    >
      <a className="skip-link" href="#main">
        Skip to content
      </a>

      <header className="site-header">
        <a className="brand" href="#top" aria-label="Critical Mass Labs home">
          <BrandMark />
          <span>Critical Mass Labs</span>
        </a>

        <nav className="desktop-nav" aria-label="Primary navigation">
          {navItems.map((item) => (
            <a key={item.href} href={item.href}>
              {item.label}
            </a>
          ))}
          <span className="system-state">
            <span className="status-dot" aria-hidden="true" />
            Sys. online
          </span>
        </nav>

        <button
          className="menu-toggle"
          type="button"
          ref={menuToggleRef}
          aria-expanded={menuOpen}
          aria-controls="mobile-navigation"
          onClick={() => (menuOpen ? closeMenu() : setMenuOpen(true))}
        >
          <span className="sr-only">
            {menuOpen ? 'Close navigation' : 'Open navigation'}
          </span>
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      <div
        className={`mobile-nav-backdrop${menuOpen ? ' is-open' : ''}`}
        aria-hidden="true"
        onClick={closeMenu}
      />
      <nav
        id="mobile-navigation"
        ref={mobileNavRef}
        className={`mobile-nav${menuOpen ? ' is-open' : ''}`}
        aria-label="Mobile navigation"
        aria-hidden={!menuOpen}
      >
        <div className="mobile-nav-head">
          <span>Navigation / Index</span>
          <span className="system-state">
            <span className="status-dot" aria-hidden="true" />
            Online
          </span>
        </div>
        {navItems.map((item, index) => (
          <a
            key={item.href}
            href={item.href}
            tabIndex={menuOpen ? 0 : -1}
            onClick={closeMenu}
          >
            <span>0{index + 1}</span>
            {item.label}
            <ArrowUpRight size={15} aria-hidden="true" />
          </a>
        ))}
      </nav>

      <main id="main" tabIndex={-1}>
        <section className="hero" aria-labelledby="hero-title">
          <div className="hero-grid" aria-hidden="true" />
          <img
            className="hero-ai-face"
            src={`${import.meta.env.BASE_URL}hero-ai-face.jpeg`}
            alt=""
            aria-hidden="true"
          />
          <div className="hero-content">
            <p className="hero-kicker">Independent research studio / 2026</p>
            <h1 id="hero-title">
              At the
              <br />
              End of the
              <br />
              <em>Dead Vector</em>
            </h1>
            <p className="hero-description">
              Research and development across systems,
              <br className="desktop-only" /> privacy, and experimental
              infrastructure.
            </p>
            <div className="hero-actions">
              <a className="button button-primary" href="#portfolio">
                Enter the SCIF
                <ExternalArrow />
              </a>
              <a className="text-link" href="#materials">
                Public materials <ExternalArrow />
              </a>
            </div>
          </div>
          <a className="scroll-cue" href="#about">
            <span>Scroll to explore</span>
            <ArrowDown size={14} aria-hidden="true" />
          </a>
          <div className="hero-coordinate" aria-hidden="true">
            <span className="coordinate-active">01</span>
            <i className="coordinate-dot active" />
            <span>Entry</span>
          </div>
        </section>

        <section className="content-section about-section" id="about">
          <div className="section-number" aria-hidden="true">
            01
          </div>
          <div className="content-column">
            <SectionLabel eyebrow="About the lab">
              A studio for the systems <em>beneath the surface.</em>
            </SectionLabel>
            <p className="lead-copy">
              Critical Mass Labs is an independent research studio exploring
              emerging systems and experimental infrastructure, with care for
              privacy and long-term consequences.
            </p>
          </div>
        </section>

        <section className="content-section method-section" id="method">
          <div className="section-number" aria-hidden="true">
            02
          </div>
          <div className="content-column method-content">
            <SectionLabel eyebrow="Operating method">
              Observe. Question. <em>Build.</em>
            </SectionLabel>
            <div className="method-grid">
              {[
                [
                  '01',
                  'Observe',
                  'Study the conditions around a problem before deciding what it should become.',
                ],
                [
                  '02',
                  'Question',
                  'Test assumptions and follow the edge cases that conventional roadmaps leave behind.',
                ],
                [
                  '03',
                  'Build',
                  'Develop careful experiments, then retain what proves useful.',
                ],
              ].map(([number, title, copy]) => (
                <article className="method-card" key={number}>
                  <span className="method-number">{number}</span>
                  <h3>{title}</h3>
                  <p>{copy}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="atlas-section" id="portfolio">
          <div className="atlas-intro">
            <div className="section-number" aria-hidden="true">
              03
            </div>
            <SectionLabel eyebrow="Project atlas / 09 coordinates">
              A field, <em>mapped.</em>
            </SectionLabel>
            <p>
              Follow an entry point or move directly through the index. Each
              coordinate opens its current public status.
            </p>
          </div>
          <div className="atlas-list" aria-label="Project atlas">
            {projects.map((project) => (
              <button
                type="button"
                className="atlas-row"
                key={project.slug}
                onClick={(event) =>
                  openProject(project, event.currentTarget)
                }
                aria-haspopup="dialog"
                aria-controls="project-status-dialog"
              >
                <span className="atlas-number">{project.number}</span>
                <span
                  className={`atlas-mark accent-${project.accent}`}
                  aria-hidden="true"
                >
                  {project.mark}
                </span>
                <span className="atlas-name">{project.name}</span>
                <span className="atlas-action">
                  View status <ExternalArrow />
                </span>
              </button>
            ))}
          </div>
        </section>

        <section className="portfolio-section">
          <div className="portfolio-heading">
            <SectionLabel eyebrow="R&D portfolio / 09 indexed programs">
              A field of <em>active questions.</em>
            </SectionLabel>
            <p>
              Each program approaches a different edge of the system. Select
              an entry to view its current public status.
            </p>
          </div>
          <div className="portfolio-grid">
            {projects.map((project) => (
              <article className="portfolio-card" key={project.slug}>
                <div className="portfolio-card-top">
                  <span className="portfolio-number">{project.number}</span>
                  <span
                    className={`portfolio-mark accent-${project.accent}`}
                    aria-hidden="true"
                  >
                    {project.mark}
                  </span>
                  <span className="portfolio-indexed">Indexed</span>
                </div>
                <h3>{project.name}</h3>
                <p>{project.description}</p>
                <button
                  className="card-status-link"
                  type="button"
                  onClick={(event) =>
                    openProject(project, event.currentTarget)
                  }
                  aria-haspopup="dialog"
                  aria-controls="project-status-dialog"
                >
                  Open status <ExternalArrow />
                </button>
              </article>
            ))}
          </div>
        </section>

        <section className="featured-project" aria-labelledby="featured-title">
          <div className="featured-art" aria-hidden="true">
            <div className="featured-scan scan-one" />
            <div className="featured-scan scan-two" />
            <div className="featured-ring" />
            <div className="featured-cross" />
          </div>
          <div className="featured-copy">
            <p className="eyebrow">
              <span className="eyebrow-line" aria-hidden="true" />
              Project 01 / Asymmetry
            </p>
            <h2 id="featured-title">
              Private coordination, <em>without spectacle.</em>
            </h2>
            <p>
              ASYMMETRY is a Critical Mass Labs research project exploring
              privacy-conscious coordination.
            </p>
            <a
              className="button button-outline"
              href="https://asymmetria.io/"
              target="_blank"
              rel="noreferrer"
            >
              Visit asymmetria.io <ExternalArrow />
            </a>
            <div className="featured-subprojects">
              <span>
                <b>⬡</b> Zero-dark <small>Pre-beta</small>
              </span>
              <span>
                <b>⌾</b> Dead drop <small>Pre-beta</small>
              </span>
            </div>
          </div>
        </section>

        <section className="featured-project obsidian-feature">
          <div className="featured-art obsidian-art" aria-hidden="true">
            <div className="obsidian-sun" />
            <div className="obsidian-grid" />
          </div>
          <div className="featured-copy">
            <p className="eyebrow">
              <span className="eyebrow-line" aria-hidden="true" />
              Skunkworks initiative
            </p>
            <h2>
              Obsidian <em>abyss.</em>
            </h2>
            <p>
              Exploratory work around systems, simulation, and uncharted
              questions.
            </p>
            <div className="featured-actions">
              <button
                className="button button-outline"
                type="button"
                onClick={(event) =>
                  openProject(projects[1], event.currentTarget)
                }
                aria-haspopup="dialog"
                aria-controls="project-status-dialog"
              >
                Open project status <ExternalArrow />
              </button>
              <a
                className="text-link"
                href="https://obsidian-abyss.xyz/"
                target="_blank"
                rel="noreferrer"
              >
                Visit Obsidian Abyss <ExternalArrow />
              </a>
            </div>
          </div>
        </section>

        <section className="materials-section content-section" id="materials">
          <div className="section-number" aria-hidden="true">
            04
          </div>
          <div className="content-column">
            <SectionLabel eyebrow="Public materials / open register">
              A record kept <em>deliberately small.</em>
            </SectionLabel>
            <p className="lead-copy">
              Selected notes, research material, and filtered snapshots appear
              here when they can be shared with useful context and appropriate
              restraint.
            </p>
            <div className="materials-list">
              <article>
                <span>Note 01 / Studio position</span>
                <h3>Working at the edge</h3>
                <p>
                  We focus on questions whose consequences reach further than
                  their first answer.
                </p>
              </article>
              <article>
                <span>Note 02 / Publication principle</span>
                <h3>Context before volume</h3>
                <p>
                  Public material is released selectively: clear enough to be
                  useful, restrained enough to be responsible.
                </p>
              </article>
              <article>
                <span>Register 03 / Status</span>
                <h3>The register is open</h3>
                <p>
                  Additional notes and research artifacts will be added
                  deliberately over time.
                </p>
              </article>
              <article className="material-link-card">
                <span>Visual 04 / Asymmetry architecture</span>
                <h3>Architecture City</h3>
                <p>
                  A safety-filtered, repository-derived city view of ASYMMETRY.
                  It preserves orientation without publishing source contents
                  or live-system claims.
                </p>
                <a
                  className="text-link"
                  href="https://cheffer0723.github.io/asymmetry-city/"
                  target="_blank"
                  rel="noreferrer"
                >
                  Open snapshot <ExternalArrow />
                </a>
              </article>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-brand">
          <a className="brand" href="#top" aria-label="Return to the top">
            <BrandMark />
            <span>Critical Mass Labs</span>
          </a>
          <p>Research and development across systems at the edge.</p>
        </div>
        <div className="footer-meta">
          <span>Public register / 2026</span>
          <a href="#top">
            Return to signal <ArrowDown size={14} aria-hidden="true" />
          </a>
        </div>
      </footer>

      {selectedProject && (
        <div className="dialog-layer">
          <button
            className="dialog-backdrop"
            type="button"
            aria-label="Close project status"
            onClick={closeProject}
          />
          <div
            id="project-status-dialog"
            className="status-dialog"
            ref={dialogRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby={`${selectedProject.slug}-dialog-title`}
            aria-describedby="project-status-dialog-description"
          >
            <div className="dialog-topline">
              <span>
                Coordinate {selectedProject.number} / Project status
              </span>
              <button
                className="dialog-close"
                type="button"
                onClick={closeProject}
                aria-label="Close project status"
              >
                <X size={19} />
              </button>
            </div>
            <div
              className={`dialog-mark accent-${selectedProject.accent}`}
              aria-hidden="true"
            >
              {selectedProject.mark}
            </div>
            <h2 id={`${selectedProject.slug}-dialog-title`}>
              {selectedProject.name}
            </h2>
            <p
              className="dialog-description"
              id="project-status-dialog-description"
            >
              {selectedProject.description}
            </p>
            <dl className="dialog-details">
              <div>
                <dt>Register status</dt>
                <dd>{selectedProject.status}</dd>
              </div>
              <div>
                <dt>Current stage</dt>
                <dd>{selectedProject.stage}</dd>
              </div>
              <div>
                <dt>Area of work</dt>
                <dd>{selectedProject.discipline}</dd>
              </div>
            </dl>
            <div className="dialog-actions">
              {selectedProject.link ? (
                <a
                  className="button button-primary"
                  href={selectedProject.link}
                  target="_blank"
                  rel="noreferrer"
                >
                  {selectedProject.linkLabel}
                  <ExternalLink size={14} aria-hidden="true" />
                </a>
              ) : (
                <span className="dialog-note">
                  Public link not published
                </span>
              )}
              <button className="text-link" type="button" onClick={closeProject}>
                Return to index <ArrowUpRight size={14} aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
    </>
  );
}

export default App;
